import { IsString, IsOptional, IsArray, IsIn } from 'class-validator';

export type VisibilityType = 'public' | 'private' | 'context-members';

export class CreateProfileDto {
  @IsString()
  name: string;

  @IsArray()
  @IsOptional()
  contextIds?: number[];

  @IsString()
  @IsIn(['public', 'private', 'context-members'])
  visibility: VisibilityType;
}
