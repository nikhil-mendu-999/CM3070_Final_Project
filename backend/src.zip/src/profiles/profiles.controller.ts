import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  Request,
  BadRequestException,
  ForbiddenException,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { ProfilesService } from './profiles.service';
import { GetProfilesQueryDto } from './dto/get-profiles.query.dto';
import { CreateProfileDto } from './dto/create-profile.dto';
import { UpdateProfileDto } from './dto/update-profile.dto';

@ApiTags('profiles')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('users/:userId/profiles')
export class ProfilesController {
  constructor(private readonly profilesService: ProfilesService) {}

  @Get()
  @ApiOperation({ summary: 'Get user profiles with visibility and context checks' })
  async getUserProfiles(
    @Request() req,
    @Param('userId') userId: string,
    @Query() query: GetProfilesQueryDto,
  ) {
    const requestingUserId = req.user.userId;
    const uid = parseInt(userId, 10);
    const cid = query.contextId;
    return this.profilesService.getUserProfiles(requestingUserId, uid, cid);
  }

  @Post('create')
  @ApiOperation({ summary: 'Create a new profile for the requesting user' })
  @ApiResponse({ status: 201, description: 'Profile created.' })
  @ApiResponse({ status: 400, description: 'Bad Request. Validation failed.' })
  @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }))
  async createProfile(
    @Request() req,
    @Body() body: CreateProfileDto
  ) {
    const userId = req.user.userId;
    return this.profilesService.createProfile(
      userId,
      body.name,
      body.contextIds || [],
      body.visibility,
    );
  }

  @Patch(':profileId')
  @ApiOperation({ summary: 'Edit profile name/context/visibility assignments' })
  @ApiResponse({ status: 200, description: 'Profile updated.' })
  @ApiResponse({ status: 400, description: 'Invalid input.' })
  @ApiResponse({ status: 401, description: 'Unauthorized.' })
  @ApiResponse({ status: 403, description: 'Forbidden. Not the profile owner.' })
  @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }))
  async updateProfile(
    @Request() req,
    @Param('profileId') profileId: string,
    @Body() body: UpdateProfileDto,
  ) {
    const userId = req.user.userId;
    return this.profilesService.updateProfile(userId, parseInt(profileId, 10), body);
  }

  @Delete(':profileId')
  @ApiOperation({ summary: 'Delete a user profile owned by the user' })
  @ApiResponse({ status: 200, description: 'Profile deleted.' })
  @ApiResponse({ status: 401, description: 'Unauthorized.' })
  @ApiResponse({ status: 403, description: 'Forbidden. Not the profile owner.' })
  async deleteProfile(
    @Request() req,
    @Param('userId') userId: string,
    @Param('profileId') profileId: string
  ) {
    return this.profilesService.deleteProfile(
      req.user.userId,
      parseInt(profileId, 10)
    );
  }
}
