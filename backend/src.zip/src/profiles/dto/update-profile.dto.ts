import { IsString, IsOptional, IsArray, ValidateNested, IsNumber, IsIn } from 'class-validator';
import { Type } from 'class-transformer';
import type { VisibilityType } from './create-profile.dto';


class ContextChangeDto {
  @IsNumber()
  contextId: number;

  @IsString()
  @IsOptional()
  displayName?: string;

  @IsString()
  @IsIn(['public', 'private', 'context-members'])
  @IsOptional()
  visibility?: VisibilityType;
}

export class UpdateProfileDto {
  @IsString()
  @IsOptional()
  name?: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ContextChangeDto)
  @IsOptional()
  contextChanges?: ContextChangeDto[];
}
