import { Injectable, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class ProfilesService {
  constructor(private readonly prisma: PrismaService) {}

  // Return profiles with filtering and visibility enforcement
  async getUserProfiles(
    requestingUserId: number,
    userId: number,
    contextId?: number,
  ) {
    const profiles = await this.prisma.profile.findMany({
      where: { userId },
      include: {
        contexts: {
          where: contextId ? { contextId } : {},
          include: {
            context: {
              include: {
                members: true,
              },
            },
          },
        },
      },
    });
    return profiles
      .map(profile => {
        const contextData = contextId
          ? profile.contexts.find(c => c.contextId === contextId)
          : null;
        return {
          id: profile.id,
          userId: profile.userId,
          name: profile.name,
          displayName: contextData?.displayName || profile.name,
          visibility: contextData?.visibility || 'private',
          context: contextData?.context || null,
        };
      })
      .filter(profile => {
        if (!contextId) {
          if (profile.userId === requestingUserId) return true;
          if (profile.visibility === 'public') return true;
          return false;
        }
        if (profile.visibility === 'public') return true;
        if (profile.visibility === 'private')
          return profile.userId === requestingUserId;
        if (profile.visibility === 'context-members') {
          return (
            profile.context?.members.some(
              m => m.userId === requestingUserId,
            ) || false
          );
        }
        return false;
      });
  }

  // Create a new profile and attach to contexts
  async createProfile(
    userId: number,
    name: string,
    contextIds: number[] = [],
    visibility: string = 'private'
  ) {
    const profile = await this.prisma.profile.create({
      data: { userId, name },
    });
    for (const contextId of contextIds) {
      await this.prisma.profileContext.create({
        data: {
          profileId: profile.id,
          contextId,
          visibility,
        }
      });
    }
    return profile;
  }

  // Update profile name and context assignments
  async updateProfile(
    userId: number,
    profileId: number,
    body: {
      name?: string;
      contextChanges?: Array<{
        contextId: number;
        displayName?: string;
        visibility?: 'public' | 'context-members' | 'private';
      }>;
    }
  ) {
    // Validate profile belongs to user
    const profile = await this.prisma.profile.findUnique({ where: { id: profileId } });
    if (!profile || profile.userId !== userId) {
      throw new ForbiddenException('Not allowed to edit this profile');
    }
    // Update the profile name if provided
    if (body.name && body.name.trim()) {
      await this.prisma.profile.update({
        where: { id: profileId },
        data: { name: body.name.trim() },
      });
    }
    // Handle context assignments
    if (body.contextChanges && Array.isArray(body.contextChanges)) {
      // Remove all existing ProfileContext links
      await this.prisma.profileContext.deleteMany({ where: { profileId } });
      // Create new ProfileContext rows for assignments
      for (const cc of body.contextChanges) {
        await this.prisma.profileContext.create({
          data: {
            profileId,
            contextId: cc.contextId,
            displayName: cc.displayName || profile.name,
            visibility: cc.visibility || 'private',
          }
        });
      }
    }
    // Return updated profile data with contexts
    return this.prisma.profile.findUnique({
      where: { id: profileId },
      include: { contexts: true },
    });
  }

  // Delete a profile securely (and all its profileContext links)
  async deleteProfile(requestingUserId: number, profileId: number) {
    const profile = await this.prisma.profile.findUnique({ where: { id: profileId } });
    if (!profile || profile.userId !== requestingUserId) {
      throw new ForbiddenException('Not allowed to delete this profile');
    }
    // Remove related ProfileContext rows
    await this.prisma.profileContext.deleteMany({ where: { profileId } });
    // Delete the profile itself
    await this.prisma.profile.delete({ where: { id: profileId } });
    return { success: true };
  }
}
