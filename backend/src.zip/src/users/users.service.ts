import { Injectable, ForbiddenException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  findAll() {
    return this.prisma.user.findMany();
  }

  findOne(id: number) {
    return this.prisma.user.findUnique({ where: { id } });
  }

  async getLinkedAccounts(userId: number) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { linkedAccounts: true }
    });
    if (!user) throw new NotFoundException('User not found');
    return user.linkedAccounts;
  }

  async deleteLinkedAccount(userId: number, linkedAccountId: number) {
    const acc = await this.prisma.userLinkedAccount.findUnique({ where: { id: linkedAccountId }});
    if (!acc || acc.userId !== userId) throw new ForbiddenException('Not allowed');
    return this.prisma.userLinkedAccount.delete({ where: { id: linkedAccountId } });
  }
}
