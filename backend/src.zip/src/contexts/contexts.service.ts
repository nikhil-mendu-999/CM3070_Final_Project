import { Injectable, ForbiddenException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
@Injectable()
export class ContextsService {
  constructor(private readonly prisma: PrismaService) {}

  findAll() { return this.prisma.context.findMany(); }
  findOne(id: number) { return this.prisma.context.findUnique({ where: { id } }); }

  async createContext(name: string, ownerId: number) {
    const context = await this.prisma.context.create({ data: { name } });
    await this.prisma.userContext.create({ data: { contextId: context.id, userId: ownerId } });
    return context;
  }

  async findUserContexts(userId: number) {
    const memberships = await this.prisma.userContext.findMany({ where: { userId }, include: { context: true } });
    return memberships.map(m => m.context);
  }

  async exportUserData(userId: number) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { profiles: { include: { contexts: true } }, contexts: true }
    });
    return { user };
  }

  async deleteUserAccount(userId: number) {
    await this.prisma.profileContext.deleteMany({ where: { profile: { userId } } });
    await this.prisma.profile.deleteMany({ where: { userId } });
    await this.prisma.userContext.deleteMany({ where: { userId } });
    await this.prisma.user.update({
      where: { id: userId },
      data: { email: `deleted_user_${userId}@anonymized.local`, passwordHash: '' }
    });
    return { success: true };
  }
  addMember(contextId: number, userId: number) { return this.prisma.userContext.create({ data: { contextId, userId } }); }
  removeMember(contextId: number, userId: number) { return this.prisma.userContext.deleteMany({ where: { contextId, userId } }); }

  // Edit/Delete Context
  async updateContext(id: number, name: string, requestingUserId: number) {
    const context = await this.prisma.context.findUnique({ where: { id }, include: { members: true } });
    if (!context) throw new BadRequestException('Context not found');
    if (!context.members.some(m => m.userId === requestingUserId))
      throw new ForbiddenException('Not allowed to edit this context');
    return this.prisma.context.update({ where: { id }, data: { name } });
  }
  async deleteContext(id: number, requestingUserId: number) {
    const context = await this.prisma.context.findUnique({ where: { id }, include: { members: true } });
    if (!context) throw new BadRequestException('Context not found');
    if (!context.members.some(m => m.userId === requestingUserId))
      throw new ForbiddenException('Not allowed to delete this context');
    await this.prisma.userContext.deleteMany({ where: { contextId: id } });
    await this.prisma.profileContext.deleteMany({ where: { contextId: id } });
    await this.prisma.context.delete({ where: { id } });
    return { success: true };
  }
}
