import { Controller, Get, Param, Request, UseGuards, Delete, ForbiddenException } from '@nestjs/common';
import { UsersService } from './users.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  findAll() {
    return this.usersService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.usersService.findOne(parseInt(id, 10));
  }

  // --- Linked Accounts Endpoints ---
  @UseGuards(JwtAuthGuard)
  @Get('me/linked-accounts')
  async getMyLinkedAccounts(@Request() req) {
    return this.usersService.getLinkedAccounts(req.user.userId);
  }

  @UseGuards(JwtAuthGuard)
  @Delete('me/linked-accounts/:id')
  async deleteMyLinkedAccount(@Request() req, @Param('id') id: string) {
    const accId = parseInt(id, 10);
    return this.usersService.deleteLinkedAccount(req.user.userId, accId);
  }
}
