import {
  Controller,
  Post,
  Body,
  UnauthorizedException,
  Get,
  Req,
  Res,
  UseGuards,
  UsePipes,
  ValidationPipe
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { AuthService } from './auth.service';
import { LoginDto } from './dto/login.dto';
import { AuthGuard } from '@nestjs/passport';
import type { Response } from 'express';

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  @ApiOperation({ summary: 'Log in with email and password, returns JWT token.' })
  @ApiResponse({ status: 201, description: 'JWT token returned.' })
  @ApiResponse({ status: 400, description: 'Bad Request. Validation failed.' })
  @ApiResponse({ status: 401, description: 'Unauthorized. Invalid credentials.' })
  @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }))
  async login(@Body() loginDto: LoginDto) {
    const user = await this.authService.validateUser(loginDto.email, loginDto.password);
    if (!user) throw new UnauthorizedException('Invalid credentials');
    return this.authService.login(user);
  }

  @Get('google')
  @UseGuards(AuthGuard('google'))
  googleAuth() {}

  @Get('google/callback')
  @UseGuards(AuthGuard('google'))
  async googleAuthRedirect(@Req() req, @Res() res: Response) {
    const user = await this.handleOAuthLogin(req.user, 'google');
    const jwtPayload = await this.authService.login(user);
    return res.redirect(`http://localhost:5173/?token=${jwtPayload.access_token}`);
  }

  @Get('github')
  @UseGuards(AuthGuard('github'))
  githubAuth() {}

  @Get('github/callback')
  @UseGuards(AuthGuard('github'))
  async githubAuthRedirect(@Req() req, @Res() res: Response) {
    const user = await this.handleOAuthLogin(req.user, 'github');
    const jwtPayload = await this.authService.login(user);
    return res.redirect(`http://localhost:5173/?token=${jwtPayload.access_token}`);
  }

  private async handleOAuthLogin(userData: any, provider: string) {
    // provider: 'google' or 'github'
    const user = await this.authService.validateOAuthUser(userData, provider);
    return user;
  }
}
