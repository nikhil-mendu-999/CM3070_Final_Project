export const jwtConstants = {
  secret: 'yourStrongSecretHereReplaceWithEnvVarInProduction',
};
