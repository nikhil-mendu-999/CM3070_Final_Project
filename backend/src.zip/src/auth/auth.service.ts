import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma.service';

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
  ) {}

  async validateUser(email: string, pass: string): Promise<any> {
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (!user || !user.passwordHash) return null;
    const isValid = await bcrypt.compare(pass, user.passwordHash);
    if (isValid) {
      const { passwordHash, ...result } = user;
      return result;
    }
    return null;
  }

  async login(user: any) {
    const dbUser = await this.prisma.user.findUnique({
      where: { id: user.id },
      include: { linkedAccounts: true },
    });
    if (!dbUser) throw new InternalServerErrorException('User not found for login');
    const payload = { username: dbUser.email, sub: dbUser.id };
    return {
      access_token: this.jwtService.sign(payload),
      userId: dbUser.id,
      email: dbUser.email,
      linkedAccounts: dbUser.linkedAccounts,
    };
  }

  async validateOAuthUser(oauthData: any, provider: string) {
    // Find existing user by email and link the social account if necessary
    let user = await this.prisma.user.findUnique({
      where: { email: oauthData.email },
      include: { linkedAccounts: true }
    });

    if (user) {
      const existingLink = await this.prisma.userLinkedAccount.findUnique({
        where: {
          provider_providerId: {
            provider,
            providerId: oauthData.providerId,
          },
        },
      });
      if (!existingLink) {
        await this.prisma.userLinkedAccount.create({
          data: {
            userId: user.id,
            provider,
            providerId: oauthData.providerId,
            displayName: oauthData.displayName,
            avatar: oauthData.avatar,
            profileUrl: oauthData.profileUrl,
          },
        });
      }
    } else {
      user = await this.prisma.user.create({
        data: {
          email: oauthData.email,
          linkedAccounts: {
            create: {
              provider,
              providerId: oauthData.providerId,
              displayName: oauthData.displayName,
              avatar: oauthData.avatar,
              profileUrl: oauthData.profileUrl,
            },
          },
        },
        include: { linkedAccounts: true },
      });
    }
    return this.prisma.user.findUnique({
      where: { email: oauthData.email },
      include: { linkedAccounts: true },
    });
  }
}
