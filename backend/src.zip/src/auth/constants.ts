export const jwtConstants = {
  secret: 'YOUR_SECRET_KEY_HERE', // Replace with env var or strong secret in production
};
