import {
  Controller, Get, Post, Patch, Delete, Param, Body, UseGuards, Request, BadRequestException,
  UsePipes, ValidationPipe
} from '@nestjs/common';
import { ContextsService } from './contexts.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CreateContextDto } from './dto/create-context.dto';
import { AddMemberDto } from './dto/add-member.dto';

@Controller('contexts')
export class ContextsController {
  constructor(private readonly contextsService: ContextsService) {}

  @Get()
  findAll() { return this.contextsService.findAll(); }

  @UseGuards(JwtAuthGuard)
  @Get('me/export')
  async exportMe(@Request() req) { return this.contextsService.exportUserData(req.user.userId); }

  @UseGuards(JwtAuthGuard)
  @Delete('me')
  async deleteMe(@Request() req) { return this.contextsService.deleteUserAccount(req.user.userId); }

  @UseGuards(JwtAuthGuard)
  @Get('me')
  findMine(@Request() req) { return this.contextsService.findUserContexts(req.user.userId); }

  @Get(':id')
  findOne(@Param('id') id: string) {
    const numId = Number(id);
    if (isNaN(numId)) throw new BadRequestException('Invalid context id (not a number).');
    return this.contextsService.findOne(numId);
  }

  @UseGuards(JwtAuthGuard)
  @Post()
  @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }))
  create(@Body() dto: CreateContextDto, @Request() req) { return this.contextsService.createContext(dto.name, req.user.userId); }

  @UseGuards(JwtAuthGuard)
  @Post(':id/members')
  addMember(@Param('id') contextId: string, @Body() dto: AddMemberDto) { return this.contextsService.addMember(Number(contextId), dto.userId); }

  @UseGuards(JwtAuthGuard)
  @Delete(':id/members/:userId')
  removeMember(@Param('id') contextId: string, @Param('userId') userId: string) {
    return this.contextsService.removeMember(Number(contextId), Number(userId));
  }

  // Edit/Delete Context
  @UseGuards(JwtAuthGuard)
  @Patch(':id')
  @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }))
  async updateContext(@Param('id') id: string, @Body() body: { name: string }, @Request() req) {
    return this.contextsService.updateContext(Number(id), body.name, req.user.userId);
  }
  @UseGuards(JwtAuthGuard)
  @Delete(':id')
  async deleteContext(@Param('id') id: string, @Request() req) {
    return this.contextsService.deleteContext(Number(id), req.user.userId);
  }
}
